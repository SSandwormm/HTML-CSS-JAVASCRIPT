var  menu = document.getElementById('container-menu');
var cerrar = document.getElementById('cerrar');
var eleccion = document.getElementById('eleccion');

function mostrar(){
    menu.style.padding = '26px 26px 200vw 200vw';
    cerrar.style.display='block';
    eleccion.style.display='flex';
}

function ocultar(){
    menu.style.padding = '26px 26px 52px 52px';
    cerrar.style.display= 'none';
    eleccion.style.display='none';
}